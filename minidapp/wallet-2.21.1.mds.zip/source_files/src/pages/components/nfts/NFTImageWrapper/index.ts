import styled from '@emotion/styled';

const NFTImageWrapper = styled('div')`
    position: relative;
`;

export default NFTImageWrapper;
