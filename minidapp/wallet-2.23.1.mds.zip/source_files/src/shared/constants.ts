export const appName = 'Wallet';
export const DRAWERWIDTH = 240;
export const MINIMA__TOKEN_ID = '0x00';
export const MINIMA__DECIMAL_PRECISION = 64;